import { createContext } from 'react';

const defaultState = {};

const PageContext = createContext(defaultState);

export default PageContext;
